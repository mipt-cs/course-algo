if __name__ == "__main__":
    n, m = map(int, input().split())
    d = [[""] * m for i in range(n)]
    d[-1][-1] = "L"
    for i in range(n-1, -1, -1):
        for j in range(m-1, -1, -1):
            for k in range(i+1, n):
                if d[k][j] == "L":
                    d[i][j] = "W"
                    break
            else:
                for k in range(j+1, m):
                    if d[i][k] == "L":
                        d[i][j] = "W"
                        break
                else:
                    d[i][j] = "L"
    print(*d[::-1], sep="\n")
