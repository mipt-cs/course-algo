def dfs(u):
    for v in a[u]:
        if d[v] != "D":
            continue
        if d[u] == "L":
            d[v] = "W"
            dfs(v)
        else:
            counter[v] += 1
            if counter[v] == deg_in[v]:
                d[v] = "L"
                dfs(v)


if __name__ == "__main__":
    n, m = map(int, input().split())
    a = {i: set() for i in range(n)}
    deg_in = [0] * n
    for _ in range(m):
        u, v = map(int, input().split())
        a[v].add(u)
        deg_in[u] += 1
    d = ["D"] * n
    for i in range(n):
        if not deg_in[i]:
            d[i] = "L"
    counter = [0] * n
    for i in range(n):
        if not deg_in[i]:
            dfs(i)
    print(d)
