def dfs(u):
    for v in a[u]:
        if d[v] == "":
            dfs(v)
        if d[v] == "L":
            d[u] = "W"
            break
    else:
        d[u] = "L"


if __name__ == "__main__":
    n, m = map(int, input().split())
    a = {i: set() for i in range(n)}
    for _ in range(m):
        u, v = map(int, input().split())
        a[u].add(v)
    d = [""] * n
    d[0] = "L"
    dfs(n-1)
    print(d[::-1])
