#include "my_stack.hpp"
#include <cassert>
#include <iostream>

void create_stack(my_stack *S)
{
	S->last = nullptr; // set last to nullptr to understand whaen it empty
}

void push_to_stack(my_stack *S, int data)
{
	node *new_node = new node;	// create new node
	new_node->data = data;		// save data to node
	new_node->next = S->last;	// save address of pervios data
	S->last = new_node;			// set new node as last added
}

int pop_from_stack(my_stack *S)
{
	assert(S->last != nullptr); // check stack is not empty
	node *old_node = S->last; 	// save old node
	S->last = old_node->next; 	// new last - next afater current last
	int res = old_node->data;	// save result data
	delete old_node;			// free unused memory
	return res;					// return result
}

void print_stack(my_stack S)
{
	node * current_node = S.last;		// set current_node is pointer to last
	while(current_node)					// while current_node is not pointer to nullptr
	{
		std::cout << current_node->data << " "; 	// print current_node data
		current_node = current_node->next;			// set current_node to next
	}
	std::cout << std::endl;				// print end line symbol
}

void delete_stack(my_stack *S)
{
	while(S->last){						// while stack in not empty
		pop_from_stack(S);				// remove last element
	}
}