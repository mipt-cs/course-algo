#ifndef __MY_STRUCT__
#define __MY_STRUCT__

struct node
{
  node *next;
  int data;
};

struct my_stack
{
  node *last;
};

void create_stack(my_stack *S);
void push_to_stack(my_stack *S, int data);
int pop_from_stack(my_stack *S);
void print_stack(my_stack S);
void delete_stack(my_stack *S);

#endif