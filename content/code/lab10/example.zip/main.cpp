#include "my_stack.hpp"
#include <iostream>

int main()
{
	my_stack S;
	create_stack(&S);

	std::cout << "Print positive integer numbers to put. Negative to push. 0 - end of input" << std::endl;
	int tmp;
	for(;;){
		std::cin >> tmp;
		if (0 == tmp) break;
		if (tmp > 0) push_to_stack(&S, tmp);
		if (tmp < 0) std::cout << "POP " << pop_from_stack(&S) << std::endl;
	}

	print_stack(S);
	delete_stack(&S);
	return 0;
}