#include "my_stack.hpp"
#include <iostream>

int main()
{
	my_stack S;
	create_stack(&S);

	std::cout << "Print integer numbers to put in stack. 0 - end of input" << std::endl;
	int tmp;
	for(;;){
		std::cin >> tmp;
		if (0 == tmp) break;
		push_to_stack(&S, tmp);
	}

	print_stack(S);
	delete_stack(&S);
	return 0;
}